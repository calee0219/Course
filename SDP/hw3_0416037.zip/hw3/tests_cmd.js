let isVal = require('./calc.js');
let isOper = require('./calc.js');

QUnit.test("calc.js isVal test", function (assert) {
  assert.equal(isVal(['val', 'ttt', 'nol']), true, "true test Passed!");
  assert.equal(isVal(['kkk', 'val', 'lala']), false, "false test Passed!");
});