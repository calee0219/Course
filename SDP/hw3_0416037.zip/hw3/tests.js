//var isOper = require('./calc.js');

QUnit.module("calc.js", function() {
  QUnit.test("Array prototype", function(assert) {
    //delete Array.prototype.back;
    let arr = [7, 1, 3, 11, 25, 9];
    assert.equal(arr.back(),9,"get the last slut correctly");
  });
  QUnit.module("function test");
  QUnit.test( "calc.js evalute test", function( assert ) {
      assert.equal(evaluate([[,5],[,'add'],[,6]]),"11", "Normal add!" );
      assert.equal(evaluate([[,4],[,'mul'],[,3]]),"12", "Normal mult!" );
      assert.equal(evaluate([[,21],[,'sub'],[,34]]),"-13", "Normal sub!" );
      assert.equal(evaluate([[,64],[,'div'],[,345]]),"0.1855072463768116", "Normal div!");
      assert.equal(evaluate([[,342],[,'mod'],[,34]]),"2", "Normal mod!" );

      assert.equal(evaluate([[,-32],[,'add'],[,373]]),"341", "Normal add!" );
      assert.equal(evaluate([[,-1],[,'mul'],[,26]]),"-26", "Normal mult!" );
      assert.equal(evaluate([[,-3],[,'sub'],[,34]]),"-37", "Normal sub!" );
      assert.equal(evaluate([[,-43],[,'div'],[,12]]),"-3.5833333333333335", "Normal div!");
      assert.equal(evaluate([[,-23],[,'mod'],[,3]]),"-2", "Normal mod!" );

      assert.equal(evaluate([[,235],[,'add'],[,-35]]),"200", "Normal add!" );
      assert.equal(evaluate([[,37],[,'mul'],[,-23]]),"-851", "Normal mult!" );
      assert.equal(evaluate([[,2345],[,'sub'],[,-37]]),"2382", "Normal sub!" );
      assert.equal(evaluate([[,56],[,'div'],[,-43]]),"-1.302325581395349", "Normal div!");
      assert.equal(evaluate([[,436],[,'mod'],[,-643]]),"436", "Normal mod!" );

      assert.equal(evaluate([[,-235],[,'add'],[,-35]]),"-270", "Normal add!" );
      assert.equal(evaluate([[,-37],[,'mul'],[,-23]]),"851", "Normal mult!" );
      assert.equal(evaluate([[,-2345],[,'sub'],[,-37]]),"-2308", "Normal sub!" );
      assert.equal(evaluate([[,-56],[,'div'],[,-43]]),"1.302325581395349", "Normal div!");
      assert.equal(evaluate([[,-436],[,'mod'],[,-643]]),"-436", "Normal mod!" );

      assert.equal(evaluate([[,1],[,'div'],[,0]]),"Infinity", "Catch div zero!" );
      assert.ok(isNaN(evaluate([[,1],[,'mod'],[,0]])), "Catch mod zero!" );

      assert.equal(evaluate([[,1],[,'add'],[,3],[,'mul'],[,5],[,'sub'],[,3]]),"13", "Long operation!");
      //assert.ok(isNaN(evaluate([[,1],[,'mod'],[,0],[,1],[,'mod'],[,0]])), "Error operation!");
  });
  QUnit.test("calc.js isVal test", function( assert ) {
    assert.equal(isVal(['val','ttt','nol']),true,"true test Passed!");
    assert.equal(isVal(['kkk','val','lala']),false,"false test Passed!");
  });
  QUnit.test("calc.js isOper test", function( assert) {
    assert.equal(isOper(['oper','pero','orpe']),true,"true test Passed!");
    assert.equal(isOper([{'aaa':'preo'},'oper','oper']),false,"false test Passed!");
  });
  QUnit.module("Calc class test", function() {
    QUnit.module("basic method test");
    QUnit.test("calc.js Calc constructor test", function( assert ) {
      const calc = new Calc;
      assert.equal(calc.base,10,"base is 10");
      assert.deepEqual(calc.buffer,[["val",0]], "buffer right");
      assert.equal(calc.value,0, "value is 0");
      assert.equal(calc.calc,false, "calc is false");
    });
    QUnit.test("calc.js Calc reset test", function( assert ) {
      const calc = new Calc;
      let tmp = [];
      tmp.push(['val',0]);
      calc.reset(2);
      assert.equal(calc.base,2,"base is 2");
      assert.deepEqual(calc.buffer,tmp, "buffer right");
      assert.equal(calc.value,0, "value is 0");
      assert.equal(calc.calc,false, "calc is false");
      calc.reset(8);
      assert.equal(calc.base,8,"base is 8");
      assert.deepEqual(calc.buffer,tmp, "buffer right");
      assert.equal(calc.value,0, "value is 0");
      assert.equal(calc.calc,false, "calc is false");
      calc.reset(10);
      assert.equal(calc.base,10,"base is 10");
      assert.deepEqual(calc.buffer,tmp, "buffer right");
      assert.equal(calc.value,0, "value is 0");
      assert.equal(calc.calc,false, "calc is false");
      calc.reset(16);
      assert.equal(calc.base,16,"base is 16");
      assert.deepEqual(calc.buffer,tmp, "buffer right");
      assert.equal(calc.value,0, "value is 0");
      assert.equal(calc.calc,false, "calc is false");
    });
    QUnit.test("calc.js Calc toString test", function( assert ) {
      const calc = new Calc;
      calc.value = 888;
      assert.equal(calc.toString("10"),"888","10 base 888 success");
      assert.equal(calc.toString("8"),"1570","8 base 888 success");
      assert.equal(calc.toString("2"),"1101111000","2 base 888 success");
      assert.equal(calc.toString("16"),"378","16 base 888 success");
      calc.value = -2342;
      assert.equal(calc.toString("10"),"-2342","10 base -2342 success");
      assert.equal(calc.toString("8"),"173332","8 base -2342 success");
      assert.equal(calc.toString("2"),"1111011011011010","2 base -2342 success");
      assert.equal(calc.toString("16"),"f6da","16 base -2342 success");
    });
    QUnit.module("16 base test");
    QUnit.test("calc.js Calc exec test (base 16)", function( assert ) {
      const calc = new Calc;
      let _cmd;
      for(let i = 0; i < 10; ++i) {
        calc.reset(16);
        _cmd = 'val-'+i;
        calc.exec(_cmd);
        assert.equal(calc.base,16,"base is 16 ");
        assert.deepEqual(calc.buffer,[['val',i]], "buffer right");
        assert.equal(calc.value,i, "value is "+i);
        assert.equal(calc.calc,false, "calc is false");
      }
      for(let i = 97; i < 103; ++i) {
        calc.reset(16);
        _cmd = 'val-'+String.fromCharCode(i);
        calc.exec(_cmd);
        assert.equal(calc.base,16,"base is 16");
        assert.deepEqual(calc.buffer,[['val',parseInt(String.fromCharCode(i),16)]], "buffer right");
        assert.equal(calc.value,parseInt(String.fromCharCode(i),16), "value is "+String.fromCharCode(i));
        assert.equal(calc.calc,false, "calc is false");
      }
      // unexpect case
      calc.reset(16);
      _cmd = 'hahaha';
      calc.exec(_cmd);
      assert.equal(calc.base,16,"test unexpect, base is 16 ");
      assert.deepEqual(calc.buffer,[['val',0]], "buffer right");
      assert.equal(calc.value,0, "value is 0");
      assert.equal(calc.calc,false, "calc is false");
    });
    QUnit.module("10 base test");
    QUnit.test("calc.js Calc exec test (base 10)", function( assert ) {
      const calc = new Calc;
      let _cmd;
      for(let i = 0; i < 10; ++i) {
        calc.reset(10);
        _cmd = 'val-'+i;
        calc.exec(_cmd);
        assert.equal(calc.base,10,"base is 10");
        assert.deepEqual(calc.buffer,[['val',i]], "buffer right");
        assert.equal(calc.value,i, "value is "+i);
        assert.equal(calc.calc,false, "calc is false");
      }
      // unexpect case
      calc.reset(10);
      _cmd = 'hahaha';
      calc.exec(_cmd);
      assert.equal(calc.base,10,"test unexpect, base is 10");
      assert.deepEqual(calc.buffer,[['val',0]], "buffer right");
      assert.equal(calc.value,0, "value is 0");
      assert.equal(calc.calc,false, "calc is false");
    });
    QUnit.module("8 base test");
    QUnit.test("calc.js Calc exec test (base 8)", function( assert ) {
      const calc = new Calc;
      let _cmd;
      for(let i = 0; i < 8; ++i) {
        calc.reset(8);
        _cmd = 'val-'+i;
        calc.exec(_cmd);
        assert.equal(calc.base,8,"test num, base is 8");
        assert.deepEqual(calc.buffer,[['val',i]], "test num, buffer right");
        assert.equal(calc.value,i, "test num, value is "+i);
        assert.equal(calc.calc,false, "test num, calc is false");
      }
      // unexpect case
      calc.reset(8);
      _cmd = 'hahaha';
      calc.exec(_cmd);
      assert.equal(calc.base,8,"test unexpect, base is 8");
      assert.deepEqual(calc.buffer,[['val',0]], "buffer right");
      assert.equal(calc.value,0, "value is 0");
      assert.equal(calc.calc,false, "calc is false");
    });
    QUnit.module("2 base test");
    QUnit.test("calc.js Calc exec test (base 2)", function( assert ) {
      const calc = new Calc;
      let _cmd;
      for(let i = 0; i < 2; ++i) {
        calc.reset(2);
        _cmd = 'val-'+i;
        calc.exec(_cmd);
        assert.equal(calc.base,2,"test num, base is 2");
        assert.deepEqual(calc.buffer,[['val',i]], "test num, buffer right");
        assert.equal(calc.value,i, "test num, value is "+i);
        assert.equal(calc.calc,false, "test num, calc is false");
      }
      // unexpect case
      calc.reset(2);
      _cmd = 'hahaha';
      calc.exec(_cmd);
      assert.equal(calc.base,2,"test unexpect, base is 2");
      assert.deepEqual(calc.buffer,[['val',0]], "buffer right");
      assert.equal(calc.value,0, "value is 0");
      assert.equal(calc.calc,false, "calc is false");
    });
    QUnit.module("16 base test");
    QUnit.test("calc.js Calc exec test function (base 16)", function( assert ) {
      const calc = new Calc;

      calc.reset(16);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-a');
      calc.exec('val-6');
      calc.exec('c');
      assert.equal(calc.base,16,"test c, base is 16");
      assert.deepEqual(calc.buffer,[['val',0]], "test c, buffer right");
      assert.equal(calc.value,0, "test c, value is 0");
      assert.equal(calc.calc,false, "test c, calc is false");

      calc.reset(16);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-f');
      calc.exec('ce');
      assert.equal(calc.base,16,"test ce, base is 16");
      assert.deepEqual(calc.buffer,[["val",8],["oper","add"],["val",0]], "test ce, buffer right");
      assert.equal(calc.value,0, "test ce, value is 0");
      assert.equal(calc.calc,false, "test ce, calc is false");

      calc.reset(16);
      calc.exec('val-b');
      calc.exec('oper-add');
      calc.exec('val-d');
      calc.exec('val-6');
      calc.exec('bs');
      assert.equal(calc.base,16,"test bs, base is 16");
      assert.deepEqual(calc.buffer,[["val",11],["oper","add"],["val",13]], "test bs, buffer right");
      assert.equal(calc.value,13, "test bs, value is 13");
      assert.equal(calc.calc,false, "test bs, calc is false");

      calc.reset(16);
      calc.exec('val-b');
      calc.exec('oper-add');
      calc.exec('val-d');
      calc.exec('val-6');
      calc.exec('oper-mul');
      calc.exec('bs');
      assert.equal(calc.base,16,"test bs, base is 16");
      assert.deepEqual(calc.buffer,[["val",11],["oper","add"],["val",214]], "test bs, buffer right");
      assert.equal(calc.value,214, "test bs, value is 214");
      assert.equal(calc.calc,false, "test bs, calc is false");

      calc.reset(16);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-a');
      calc.exec('neg');
      assert.equal(calc.base,16,"test neg, base is 16");
      assert.deepEqual(calc.buffer,[["val",8],["oper","add"],["val",-58]], "test neg, buffer right");
      assert.equal(calc.value,-58, "test neg, value is -58");
      assert.equal(calc.calc,false, "test neg, calc is false");

      calc.reset(16);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-a');
      calc.exec('oper-add');
      calc.exec('neg');
      assert.equal(calc.base,16,"test neg, base is 16");
      assert.deepEqual(calc.buffer,[["val",8],["oper","add"],["val",-58],["oper","add"],["val",0]], "test neg, buffer right");
      assert.equal(calc.value,0, "test neg, value is 0");
      assert.equal(calc.calc,false, "test neg, calc is false");

      calc.reset(16);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('oper-add');
      calc.exec('ce');
      calc.exec('calc');
      assert.equal(calc.base,16,"test calc, base is 16");
      assert.deepEqual(calc.buffer,[["val",44]], "test calc, buffer right");
      assert.equal(calc.value,44, "test calc, value is 44");
      assert.equal(calc.calc,true, "test calc, calc is ture");
    });
    QUnit.module("10 base test");
    QUnit.test("calc.js Calc exec test function (base 10)", function( assert ) {
      const calc = new Calc;

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('c');
      assert.equal(calc.base,10,"test c, base is 10");
      assert.deepEqual(calc.buffer,[['val',0]], "test c, buffer right");
      assert.equal(calc.value,0, "test c, value is 0");
      assert.equal(calc.calc,false, "test c, calc is false");

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('ce');
      assert.equal(calc.base,10,"test ce, base is 10");
      assert.deepEqual(calc.buffer,[["val",8],["oper","add"],["val",0]], "test ce, buffer right");
      assert.equal(calc.value,0, "test ce, value is 0");
      assert.equal(calc.calc,false, "test ce, calc is false");

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('bs');
      assert.equal(calc.base,10,"test bs, base is 10");
      assert.deepEqual(calc.buffer,[["val",8],["oper","add"],["val",3]], "test bs, buffer right");
      assert.equal(calc.value,3, "test bs, value is 3");
      assert.equal(calc.calc,false, "test bs, calc is false");

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('oper-add');
      calc.exec('bs');
      assert.equal(calc.base,10,"test bs, base is 10");
      assert.deepEqual(calc.buffer,[["val",8],["oper","add"],["val",36]], "test bs, buffer right");
      assert.equal(calc.value,36, "test bs, value is 36");
      assert.equal(calc.calc,false, "test bs, calc is false");

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('neg');
      assert.equal(calc.base,10,"test neg, base is 10");
      assert.deepEqual(calc.buffer,[["val",8],["oper","add"],["val",-36]], "test neg, buffer right");
      assert.equal(calc.value,-36, "test neg, value is -36");
      assert.equal(calc.calc,false, "test neg, calc is false");

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('oper-add');
      calc.exec('neg');
      assert.equal(calc.base,10,"test neg, base is 10");
      assert.deepEqual(calc.buffer,[["val",8],["oper","add"],["val",-36],["oper","add"],["val",0]], "test neg, buffer right");
      assert.equal(calc.value,0, "test neg, value is 0");
      assert.equal(calc.calc,false, "test neg, calc is false");

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('oper-add');
      calc.exec('ce');
      calc.exec('calc');
      assert.equal(calc.base,10,"test calc, base is 10");
      assert.deepEqual(calc.buffer,[["val",44]  ], "test calc, buff right");
      assert.equal(calc.value,44, "test calc, value is 44");
      assert.equal(calc.calc,true, "test calc, calc is ture");
    });
    QUnit.module("8 base test");
    QUnit.test("calc.js Calc exec test function (base 8)", function( assert ) {
      const calc = new Calc;

      calc.reset(8);
      calc.exec('val-7');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('c');
      assert.equal(calc.base,8,"test c, base is 8");
      assert.deepEqual(calc.buffer,[['val',0]], "test c, buff right");
      assert.equal(calc.value,0, "test c, value is 0");
      assert.equal(calc.calc,false, "test c, calc is false");

      calc.reset(8);
      calc.exec('val-4');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('ce');
      assert.equal(calc.base,8,"test ce, base is 8");
      assert.deepEqual(calc.buffer,[["val",4],["oper","add"],["val",0]], "test ce, buff right");
      assert.equal(calc.value,0, "test ce, value is 0");
      assert.equal(calc.calc,false, "test ce, calc is false");

      calc.reset(8);
      calc.exec('val-5');
      calc.exec('oper-mul');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('bs');
      assert.equal(calc.base,8,"test bs, base is 8");
      assert.deepEqual(calc.buffer,[["val",5],["oper","mul"],["val",3]], "test bs, buff right");
      assert.equal(calc.value,3, "test bs, value is 3");
      assert.equal(calc.calc,false, "test bs, calc is false");

      calc.reset(8);
      calc.exec('val-5');
      calc.exec('oper-mul');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('oper-add');
      calc.exec('bs');
      assert.equal(calc.base,8,"test bs, base is 8");
      assert.deepEqual(calc.buffer,[["val",5],["oper","mul"],["val",36]], "test bs, buff right");
      assert.equal(calc.value,36, "test bs, value is 36");
      assert.equal(calc.calc,false, "test bs, calc is false");

      calc.reset(8);
      calc.exec('val-2');
      calc.exec('oper-sub');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('neg');
      assert.equal(calc.base,8,"test neg, base is 8");
      assert.deepEqual(calc.buffer,[["val",2],["oper","sub"],["val",-30]], "test neg, buff right");
      assert.equal(calc.value,-30, "test neg, value is -30  ");
      assert.equal(calc.calc,false, "test neg, calc is false");

      calc.reset(8);
      calc.exec('val-2');
      calc.exec('oper-sub');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('oper-sub');
      calc.exec('neg');
      assert.equal(calc.base,8,"test neg, base is 8");
      assert.deepEqual(calc.buffer,[["val",2],["oper","sub"],["val",-30],["oper","sub"],["val",0]], "test neg, buff right");
      assert.equal(calc.value,0, "test neg, value is 0");
      assert.equal(calc.calc,false, "test neg, calc is false");

      calc.reset(8);
      calc.exec('val-6');
      calc.exec('oper-add');
      calc.exec('val-3');
      calc.exec('val-6');
      calc.exec('oper-add');
      calc.exec('ce');
      calc.exec('calc');
      assert.equal(calc.base,8,"test calc, base is 8");
      assert.deepEqual(calc.buffer,[["val",44]  ], "test calc, buff right");
      assert.equal(calc.value,44, "test calc, value is 44");
      assert.equal(calc.calc,true, "test calc, calc is ture");
    });
    QUnit.module("2 base test");
    QUnit.test("calc.js Calc exec test function (base 2)", function( assert ) {
      const calc = new Calc;

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-add');
      calc.exec('val-0');
      calc.exec('val-1');
      calc.exec('c');
      assert.equal(calc.base,2,"test c, base is 2");
      assert.deepEqual(calc.buffer,[['val',0]], "test c, buff right");
      assert.equal(calc.value,0, "test c, value is 0");
      assert.equal(calc.calc,false, "test c, calc is false");

      calc.reset(2);
      calc.exec('val-0');
      calc.exec('oper-add');
      calc.exec('val-1');
      calc.exec('val-0');
      calc.exec('ce');
      assert.equal(calc.base,2,"test ce, base is 2");
      assert.deepEqual(calc.buffer,[["val",0],["oper","add"],["val",0]], "test ce, buff right");
      assert.equal(calc.value,0, "test ce, value is 0");
      assert.equal(calc.calc,false, "test ce, calc is false");

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-mul');
      calc.exec('val-0');
      calc.exec('val-0');
      calc.exec('bs');
      assert.equal(calc.base,2,"test bs, base is 2");
      assert.deepEqual(calc.buffer,[["val",1],["oper","mul"],["val",0]], "test bs, buff right");
      assert.equal(calc.value,0, "test bs, value is 0");
      assert.equal(calc.calc,false, "test bs, calc is false");

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-mul');
      calc.exec('val-0');
      calc.exec('val-0');
      calc.exec('oper-add');
      calc.exec('bs');
      assert.equal(calc.base,2,"test bs, base is 2");
      assert.deepEqual(calc.buffer,[["val",1],["oper","mul"],["val",0]], "test bs, buff right");
      assert.equal(calc.value,0, "test bs, value is 0");
      assert.equal(calc.calc,false, "test bs, calc is false");

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-sub');
      calc.exec('val-1');
      calc.exec('val-1');
      calc.exec('neg');
      assert.equal(calc.base,2,"test neg, base is 2");
      assert.deepEqual(calc.buffer,[["val",1],["oper","sub"],["val",-3]], "test neg, buff right");
      assert.equal(calc.value,-3, "test neg, value is -3");
      assert.equal(calc.calc,false, "test neg, calc is false");

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-sub');
      calc.exec('val-1');
      calc.exec('val-1');
      calc.exec('oper-sub');
      calc.exec('neg');
      assert.equal(calc.base,2,"test neg, base is 2");
      assert.deepEqual(calc.buffer,[["val",1],["oper","sub"],["val",-3],["oper","sub"],["val",0]], "test neg, buff right");
      assert.equal(calc.value,0, "test neg, value is 0");
      assert.equal(calc.calc,false, "test neg, calc is false");

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-add');
      calc.exec('val-1');
      calc.exec('val-0');
      calc.exec('oper-add');
      calc.exec('ce');
      calc.exec('calc');
      assert.equal(calc.base,2,"test calc, base is 2");
      assert.deepEqual(calc.buffer,[["val",11]], "test calc, buff right");
      assert.equal(calc.value,3, "test calc, value is 44");
      assert.equal(calc.calc,true, "test calc, calc is ture");
    });
    QUnit.module("16 base test");
    QUnit.test("calc.js Calc exec test oper (base 16)", function( assert ) {
      const calc = new Calc;

      calc.reset(16);
      calc.exec('val-8');
      calc.exec('oper-add');
      assert.equal(calc.base,16,"test add, base is 16");
      assert.deepEqual(calc.buffer,[["val",8],["oper","add"]], "test add, buff right");
      assert.equal(calc.value,8, "test add, value is 8");
      assert.equal(calc.calc,false, "test add, calc is false");

      calc.reset(16);
      calc.exec('val-8');
      calc.exec('oper-sub');
      assert.equal(calc.base,16,"test sub, base is 16");
      assert.deepEqual(calc.buffer,[["val",8],["oper","sub"]], "test sub, buff right");
      assert.equal(calc.value,8, "test sub, value is 8");
      assert.equal(calc.calc,false, "test sub, calc is false");

      calc.reset(16);
      calc.exec('val-8');
      calc.exec('oper-mul');
      assert.equal(calc.base,16,"test mul, base is 16");
      assert.deepEqual(calc.buffer,[["val",8],["oper","mul"]], "test mul, buff right");
      assert.equal(calc.value,8, "test mul, value is 8");
      assert.equal(calc.calc,false, "test mul, calc is false");

      calc.reset(16);
      calc.exec('val-8');
      calc.exec('oper-div');
      assert.equal(calc.base,16,"test div, base is 16");
      assert.deepEqual(calc.buffer,[["val",8],["oper","div"]], "test div, buff right");
      assert.equal(calc.value,8, "test div, value is 8");
      assert.equal(calc.calc,false, "test div, calc is false");

      calc.reset(16);
      calc.exec('val-8');
      calc.exec('oper-mod');
      assert.equal(calc.base,16,"test mod, base is 16");
      assert.deepEqual(calc.buffer,[["val",8],["oper","mod"]], "test mod, buff right");
      assert.equal(calc.value,8, "test mod, value is 8");
      assert.equal(calc.calc,false, "test mod, calc is false");
    });
    QUnit.module("10 base test");
    QUnit.test("calc.js Calc exec test oper (base 10)", function( assert ) {
      const calc = new Calc;

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-add');
      assert.equal(calc.base,10,"test add, base is 10");
      assert.deepEqual(calc.buffer,[["val",8],["oper","add"]], "test add, buff right");
      assert.equal(calc.value,8, "test add, value is 8");
      assert.equal(calc.calc,false, "test add, calc is false");

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-sub');
      assert.equal(calc.base,10,"test sub, base is 10");
      assert.deepEqual(calc.buffer,[["val",8],["oper","sub"]], "test sub, buff right");
      assert.equal(calc.value,8, "test sub, value is 8");
      assert.equal(calc.calc,false, "test sub, calc is false");

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-mul');
      assert.equal(calc.base,10,"test mul, base is 10");
      assert.deepEqual(calc.buffer,[["val",8],["oper","mul"]], "test mul, buff right");
      assert.equal(calc.value,8, "test mul, value is 8");
      assert.equal(calc.calc,false, "test mul, calc is false");

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-div');
      assert.equal(calc.base,10,"test div, base is 10");
      assert.deepEqual(calc.buffer,[["val",8],["oper","div"]], "test div, buff right");
      assert.equal(calc.value,8, "test div, value is 8");
      assert.equal(calc.calc,false, "test div, calc is false");

      calc.reset(10);
      calc.exec('val-8');
      calc.exec('oper-mod');
      assert.equal(calc.base,10,"test mod, base is 10");
      assert.deepEqual(calc.buffer,[["val",8],["oper","mod"]], "test mod, buff right");
      assert.equal(calc.value,8, "test mod, value is 8");
      assert.equal(calc.calc,false, "test mod, calc is false");
    });
    QUnit.module("8 base test");
    QUnit.test("calc.js Calc exec test oper (base 8)", function( assert ) {
      const calc = new Calc;

      calc.reset(8);
      calc.exec('val-3');
      calc.exec('oper-add');
      assert.equal(calc.base,8,"test add, base is 8");
      assert.deepEqual(calc.buffer,[["val",3],["oper","add"]], "test add, buff right");
      assert.equal(calc.value,3, "test add, value is 3");
      assert.equal(calc.calc,false, "test add, calc is false");

      calc.reset(8);
      calc.exec('val-3');
      calc.exec('oper-sub');
      assert.equal(calc.base,8,"test sub, base is 8");
      assert.deepEqual(calc.buffer,[["val",3],["oper","sub"]], "test sub, buff right");
      assert.equal(calc.value,3, "test sub, value is 3");
      assert.equal(calc.calc,false, "test sub, calc is false");

      calc.reset(8);
      calc.exec('val-3');
      calc.exec('oper-mul');
      assert.equal(calc.base,8,"test mul, base is 8");
      assert.deepEqual(calc.buffer,[["val",3],["oper","mul"]], "test mul, buff right");
      assert.equal(calc.value,3, "test mul, value is 3");
      assert.equal(calc.calc,false, "test mul, calc is false");

      calc.reset(8);
      calc.exec('val-3');
      calc.exec('oper-div');
      assert.equal(calc.base,8,"test div, base is 8");
      assert.deepEqual(calc.buffer,[["val",3],["oper","div"]], "test div, buff right");
      assert.equal(calc.value,3, "test div, value is 3");
      assert.equal(calc.calc,false, "test div, calc is false");

      calc.reset(8);
      calc.exec('val-3');
      calc.exec('oper-mod');
      assert.equal(calc.base,8,"test mod, base is 8");
      assert.deepEqual(calc.buffer,[["val",3],["oper","mod"]], "test mod, buff right");
      assert.equal(calc.value,3, "test mod, value is 3");
      assert.equal(calc.calc,false, "test mod, calc is false");
    });
    QUnit.module("2 base test");
    QUnit.test("calc.js Calc exec test oper (base 2)", function( assert ) {
      const calc = new Calc;

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-add');
      assert.equal(calc.base,2,"test add, base is 2");
      assert.deepEqual(calc.buffer,[["val",1],["oper","add"]], "test add, buff right");
      assert.equal(calc.value,1, "test add, value is 1");
      assert.equal(calc.calc,false, "test add, calc is false");

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-sub');
      assert.equal(calc.base,2,"test sub, base is 2");
      assert.deepEqual(calc.buffer,[["val",1],["oper","sub"]], "test sub, buff right");
      assert.equal(calc.value,1, "test sub, value is 1");
      assert.equal(calc.calc,false, "test sub, calc is false");

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-mul');
      assert.equal(calc.base,2,"test mul, base is 2");
      assert.deepEqual(calc.buffer,[["val",1],["oper","mul"]], "test mul, buff right");
      assert.equal(calc.value,1, "test mul, value is 1");
      assert.equal(calc.calc,false, "test mul, calc is false");

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-div');
      assert.equal(calc.base,2,"test div, base is 2");
      assert.deepEqual(calc.buffer,[["val",1],["oper","div"]], "test div, buff right");
      assert.equal(calc.value,1, "test div, value is 1");
      assert.equal(calc.calc,false, "test div, calc is false");

      calc.reset(2);
      calc.exec('val-1');
      calc.exec('oper-mod');
      assert.equal(calc.base,2,"test mod, base is 2");
      assert.deepEqual(calc.buffer,[["val",1],["oper","mod"]], "test mod, buff right");
      assert.equal(calc.value,1, "test mod, value is 1");
      assert.equal(calc.calc,false, "test mod, calc is false");
    });
  });
});

// test main.js
QUnit.module("main.js DOM test", function() {
  QUnit.module("keyboard testing", function() {
    QUnit.test("base test", function (assert) {
      let done = assert.async();
      init();
      Mousetrap.trigger('h e x');
      setTimeout(function(){
        assert.ok($('div.calc').hasClass('hex'),"hex correct");
        Mousetrap.trigger('d e c');
        setTimeout(function(){
          assert.ok($('div.calc').hasClass('dec'),"dec correct");
          Mousetrap.trigger('o c t');
          setTimeout(function(){
            assert.ok($('div.calc').hasClass('oct'),"oct correct");
            Mousetrap.trigger('b i n');
            setTimeout(function(){
              assert.ok($('div.calc').hasClass('bin'),"bin correct");
              done();
            });
          });
        });
      });
    });
    QUnit.test("help test", function (assert) {
      let done = assert.async();
      init();
      Mousetrap.trigger('?');
      setTimeout(function () {
        assert.ok($('.help-wrapper').css('display'), 'help appear');
        Mousetrap.trigger('?');
        setTimeout(function () {
          assert.equal($('.help-wrapper').css('display'), 'none', "help fade");
          done();
        }, 500);
      }, 500);
    });
    QUnit.module("disabled testing");
    QUnit.test("hex disabled test", function (assert) {
      let done = assert.async();
      init();
      Mousetrap.trigger('h e x');
      setTimeout(function () {
        assert.ok(!$('.button[data-content="val-f"]').hasClass('disabled'), "f no disabled true");
        assert.ok(!$('.button[data-content="val-e"]').hasClass('disabled'), "e no disabled true");
        assert.ok(!$('.button[data-content="val-d"]').hasClass('disabled'), "d no disabled true");
        assert.ok(!$('.button[data-content="val-c"]').hasClass('disabled'), "c no disabled true");
        assert.ok(!$('.button[data-content="val-b"]').hasClass('disabled'), "b no disabled true");
        assert.ok(!$('.button[data-content="val-a"]').hasClass('disabled'), "a no disabled true");
        assert.ok(!$('.button[data-content="val-9"]').hasClass('disabled'), "9 no disabled true");
        assert.ok(!$('.button[data-content="val-8"]').hasClass('disabled'), "8 no disabled true");
        assert.ok(!$('.button[data-content="val-7"]').hasClass('disabled'), "7 no disabled true");
        assert.ok(!$('.button[data-content="val-6"]').hasClass('disabled'), "6 no disabled true");
        assert.ok(!$('.button[data-content="val-5"]').hasClass('disabled'), "5 no disabled true");
        assert.ok(!$('.button[data-content="val-4"]').hasClass('disabled'), "4 no disabled true");
        assert.ok(!$('.button[data-content="val-3"]').hasClass('disabled'), "3 no disabled true");
        assert.ok(!$('.button[data-content="val-2"]').hasClass('disabled'), "2 no disabled true");
        assert.ok(!$('.button[data-content="val-1"]').hasClass('disabled'), "1 no disabled true");
        assert.ok(!$('.button[data-content="val-0"]').hasClass('disabled'), "0 no disabled true");
        done();
      });
    });
    QUnit.test("dec disabled test", function (assert) {
      let done = assert.async();
      init();
      Mousetrap.trigger('d e x');
      setTimeout(function () {
        assert.ok($('.button[data-content="val-f"]').hasClass('disabled'), "f disabled true");
        assert.ok($('.button[data-content="val-e"]').hasClass('disabled'), "e disabled true");
        assert.ok($('.button[data-content="val-d"]').hasClass('disabled'), "d disabled true");
        assert.ok($('.button[data-content="val-c"]').hasClass('disabled'), "c disabled true");
        assert.ok($('.button[data-content="val-b"]').hasClass('disabled'), "b disabled true");
        assert.ok($('.button[data-content="val-a"]').hasClass('disabled'), "a disabled true");
        assert.ok(!$('.button[data-content="val-9"]').hasClass('disabled'), "9 no disabled true");
        assert.ok(!$('.button[data-content="val-8"]').hasClass('disabled'), "8 no disabled true");
        assert.ok(!$('.button[data-content="val-7"]').hasClass('disabled'), "7 no disabled true");
        assert.ok(!$('.button[data-content="val-6"]').hasClass('disabled'), "6 no disabled true");
        assert.ok(!$('.button[data-content="val-5"]').hasClass('disabled'), "5 no disabled true");
        assert.ok(!$('.button[data-content="val-4"]').hasClass('disabled'), "4 no disabled true");
        assert.ok(!$('.button[data-content="val-3"]').hasClass('disabled'), "3 no disabled true");
        assert.ok(!$('.button[data-content="val-2"]').hasClass('disabled'), "2 no disabled true");
        assert.ok(!$('.button[data-content="val-1"]').hasClass('disabled'), "1 no disabled true");
        assert.ok(!$('.button[data-content="val-0"]').hasClass('disabled'), "0 no disabled true");
        done();
      });
    });
    QUnit.test("oct disabled test", function (assert) {
      let done = assert.async();
      init();
      Mousetrap.trigger('o c t');
      setTimeout(function () {
        assert.ok($('.button[data-content="val-f"]').hasClass('disabled'), "f disabled true");
        assert.ok($('.button[data-content="val-e"]').hasClass('disabled'), "e disabled true");
        assert.ok($('.button[data-content="val-d"]').hasClass('disabled'), "d disabled true");
        assert.ok($('.button[data-content="val-c"]').hasClass('disabled'), "c disabled true");
        assert.ok($('.button[data-content="val-b"]').hasClass('disabled'), "b disabled true");
        assert.ok($('.button[data-content="val-a"]').hasClass('disabled'), "a disabled true");
        assert.ok($('.button[data-content="val-9"]').hasClass('disabled'), "9 disabled true");
        assert.ok($('.button[data-content="val-8"]').hasClass('disabled'), "8 disabled true");
        assert.ok(!$('.button[data-content="val-7"]').hasClass('disabled'), "7 no disabled true");
        assert.ok(!$('.button[data-content="val-6"]').hasClass('disabled'), "6 no disabled true");
        assert.ok(!$('.button[data-content="val-5"]').hasClass('disabled'), "5 no disabled true");
        assert.ok(!$('.button[data-content="val-4"]').hasClass('disabled'), "4 no disabled true");
        assert.ok(!$('.button[data-content="val-3"]').hasClass('disabled'), "3 no disabled true");
        assert.ok(!$('.button[data-content="val-2"]').hasClass('disabled'), "2 no disabled true");
        assert.ok(!$('.button[data-content="val-1"]').hasClass('disabled'), "1 no disabled true");
        assert.ok(!$('.button[data-content="val-0"]').hasClass('disabled'), "0 no disabled true");
        done();
      });
    });
    QUnit.test("bin disabled test", function (assert) {
      let done = assert.async();
      init();
      Mousetrap.trigger('b i n');
      setTimeout(function () {
        assert.ok($('.button[data-content="val-f"]').hasClass('disabled'), "f disabled true");
        assert.ok($('.button[data-content="val-e"]').hasClass('disabled'), "e disabled true");
        assert.ok($('.button[data-content="val-d"]').hasClass('disabled'), "d disabled true");
        assert.ok($('.button[data-content="val-c"]').hasClass('disabled'), "c disabled true");
        assert.ok($('.button[data-content="val-b"]').hasClass('disabled'), "b disabled true");
        assert.ok($('.button[data-content="val-a"]').hasClass('disabled'), "a disabled true");
        assert.ok($('.button[data-content="val-9"]').hasClass('disabled'), "9 disabled true");
        assert.ok($('.button[data-content="val-8"]').hasClass('disabled'), "8 disabled true");
        assert.ok($('.button[data-content="val-7"]').hasClass('disabled'), "7 disabled true");
        assert.ok($('.button[data-content="val-6"]').hasClass('disabled'), "6 disabled true");
        assert.ok($('.button[data-content="val-5"]').hasClass('disabled'), "5 disabled true");
        assert.ok($('.button[data-content="val-4"]').hasClass('disabled'), "4 disabled true");
        assert.ok($('.button[data-content="val-3"]').hasClass('disabled'), "3 disabled true");
        assert.ok($('.button[data-content="val-2"]').hasClass('disabled'), "2 disabled true");
        assert.ok(!$('.button[data-content="val-1"]').hasClass('disabled'), "1 no disabled true");
        assert.ok(!$('.button[data-content="val-0"]').hasClass('disabled'), "0 no disabled true");
        done();
      });
    });
    QUnit.module("monkey test");
    QUnit.test("keyboard dec monkey test", function (assert) {
      let done = assert.async();
      init();
      Mousetrap.trigger('3');
      Mousetrap.trigger('7');
      Mousetrap.trigger('8');
      setTimeout(function () {
        assert.equal($('.display .value').html(), '378', "number pass");
        Mousetrap.trigger('/');
        setTimeout(function () {
          assert.equal($('.display .value').html(), '378', "div pass");
          Mousetrap.trigger('2');
          Mousetrap.trigger('1');
          setTimeout(function () {
            assert.equal($('.display .value').html(), '21', "number pass");
            Mousetrap.trigger('-');
            Mousetrap.trigger('+');
            setTimeout(function () {
              assert.equal($('.display .value').html(), '21', "add, sub pass, change oper pass");
              Mousetrap.trigger('9');
              Mousetrap.trigger('4');
              setTimeout(function () {
                assert.equal($('.display .value').html(), '94', "number pass");
                Mousetrap.trigger('%');
                setTimeout(function () {
                  assert.equal($('.display .value').html(), '94', "mod");
                  Mousetrap.trigger('0');
                  Mousetrap.trigger('6');
                  Mousetrap.trigger('enter');
                  setTimeout(function () {
                    assert.equal($('.display .value').html(), '22', "enter pass");
                    Mousetrap.trigger('esc');
                    setTimeout(function () {
                      assert.equal($('.display .value').html(), '0', "clear pass");
                      Mousetrap.trigger('5');
                      Mousetrap.trigger('a');
                      Mousetrap.trigger('b');
                      Mousetrap.trigger('c');
                      Mousetrap.trigger('d');
                      Mousetrap.trigger('e');
                      Mousetrap.trigger('f');
                      setTimeout(function () {
                        assert.equal($('.display .value').html(), '5', "dec 10~15 disabled");
                        Mousetrap.trigger('*');
                        Mousetrap.trigger('4');
                        Mousetrap.trigger('1');
                        Mousetrap.trigger('backspace');
                        setTimeout(function () {
                          assert.equal($('.display .value').html(), '4', "bs pass");
                          Mousetrap.trigger('2');
                          setTimeout(function () {
                            assert.equal($('.display .value').html(), '42', "neg pass");
                            Mousetrap.trigger('c e');
                            Mousetrap.trigger('9');
                            Mousetrap.trigger('=');
                            setTimeout(function () {
                              assert.equal($('.display .value').html(), '45', "ce pass");
                              done();
                            });
                          });
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
  QUnit.module("mouse test", function() {
    QUnit.test("base test", function (assert) {
      let done = assert.async();
      init();
      $('.hex').trigger('click');
      setTimeout(function () {
        assert.ok($('div.calc').hasClass('hex'), "hex correct");
        $('.dec').trigger('click');
        setTimeout(function () {
          assert.ok($('div.calc').hasClass('dec'), "dec correct");
          $('.oct').trigger('click');
          setTimeout(function () {
            assert.ok($('div.calc').hasClass('oct'), "oct correct");
            $('.bin').trigger('click');
            setTimeout(function () {
              assert.ok($('div.calc').hasClass('bin'), "bin correct");
              done();
            });
          });
        });
      });
    });
    QUnit.test("help test", function (assert) {
      init();
      let done = assert.async();

      $('.help-btn').trigger('click');
      setTimeout(function () {
        assert.ok($('.help-wrapper').css('display'), 'help appear');
        $('.help-btn').trigger('click');
        setTimeout(function () {
          assert.equal($('.help-wrapper').css('display'), 'none', "help fade");
          $('help-btn').trigger('click');
          setTimeout(function() {
            assert.ok($('.help-wrapper').css('display'), 'help appear');
            $('.help-wrapper').trigger('click');
            setTimeout(function() {
              assert.equal($('.help-wrapper').css('display'), 'none', "wrapper test, help fade");
              done();
            });
          });
        }, 500);
      }, 500);
    });
    QUnit.module('disable test');
    QUnit.test("hex disabled test", function (assert) {
      let done = assert.async();
      init();
      $('.base.hex').trigger('click');
      setTimeout(function () {
        assert.ok(!$('.button[data-content="val-f"]').hasClass('disabled'), "f no disabled true");
        assert.ok(!$('.button[data-content="val-e"]').hasClass('disabled'), "e no disabled true");
        assert.ok(!$('.button[data-content="val-d"]').hasClass('disabled'), "d no disabled true");
        assert.ok(!$('.button[data-content="val-c"]').hasClass('disabled'), "c no disabled true");
        assert.ok(!$('.button[data-content="val-b"]').hasClass('disabled'), "b no disabled true");
        assert.ok(!$('.button[data-content="val-a"]').hasClass('disabled'), "a no disabled true");
        assert.ok(!$('.button[data-content="val-9"]').hasClass('disabled'), "9 no disabled true");
        assert.ok(!$('.button[data-content="val-8"]').hasClass('disabled'), "8 no disabled true");
        assert.ok(!$('.button[data-content="val-7"]').hasClass('disabled'), "7 no disabled true");
        assert.ok(!$('.button[data-content="val-6"]').hasClass('disabled'), "6 no disabled true");
        assert.ok(!$('.button[data-content="val-5"]').hasClass('disabled'), "5 no disabled true");
        assert.ok(!$('.button[data-content="val-4"]').hasClass('disabled'), "4 no disabled true");
        assert.ok(!$('.button[data-content="val-3"]').hasClass('disabled'), "3 no disabled true");
        assert.ok(!$('.button[data-content="val-2"]').hasClass('disabled'), "2 no disabled true");
        assert.ok(!$('.button[data-content="val-1"]').hasClass('disabled'), "1 no disabled true");
        assert.ok(!$('.button[data-content="val-0"]').hasClass('disabled'), "0 no disabled true");
        done();
      });
    });
    QUnit.test("dec disabled test", function (assert) {
      let done = assert.async();
      init();
      $('.base.dec').trigger('click');
      setTimeout(function () {
        assert.ok($('.button[data-content="val-f"]').hasClass('disabled'), "f disabled true");
        assert.ok($('.button[data-content="val-e"]').hasClass('disabled'), "e disabled true");
        assert.ok($('.button[data-content="val-d"]').hasClass('disabled'), "d disabled true");
        assert.ok($('.button[data-content="val-c"]').hasClass('disabled'), "c disabled true");
        assert.ok($('.button[data-content="val-b"]').hasClass('disabled'), "b disabled true");
        assert.ok($('.button[data-content="val-a"]').hasClass('disabled'), "a disabled true");
        assert.ok(!$('.button[data-content="val-9"]').hasClass('disabled'), "9 no disabled true");
        assert.ok(!$('.button[data-content="val-8"]').hasClass('disabled'), "8 no disabled true");
        assert.ok(!$('.button[data-content="val-7"]').hasClass('disabled'), "7 no disabled true");
        assert.ok(!$('.button[data-content="val-6"]').hasClass('disabled'), "6 no disabled true");
        assert.ok(!$('.button[data-content="val-5"]').hasClass('disabled'), "5 no disabled true");
        assert.ok(!$('.button[data-content="val-4"]').hasClass('disabled'), "4 no disabled true");
        assert.ok(!$('.button[data-content="val-3"]').hasClass('disabled'), "3 no disabled true");
        assert.ok(!$('.button[data-content="val-2"]').hasClass('disabled'), "2 no disabled true");
        assert.ok(!$('.button[data-content="val-1"]').hasClass('disabled'), "1 no disabled true");
        assert.ok(!$('.button[data-content="val-0"]').hasClass('disabled'), "0 no disabled true");
        done();
      });
    });
    QUnit.test("oct disabled test", function (assert) {
      let done = assert.async();
      init();
      $('.base.oct').trigger('click');
      setTimeout(function () {
        assert.ok($('.button[data-content="val-f"]').hasClass('disabled'), "f disabled true");
        assert.ok($('.button[data-content="val-e"]').hasClass('disabled'), "e disabled true");
        assert.ok($('.button[data-content="val-d"]').hasClass('disabled'), "d disabled true");
        assert.ok($('.button[data-content="val-c"]').hasClass('disabled'), "c disabled true");
        assert.ok($('.button[data-content="val-b"]').hasClass('disabled'), "b disabled true");
        assert.ok($('.button[data-content="val-a"]').hasClass('disabled'), "a disabled true");
        assert.ok($('.button[data-content="val-9"]').hasClass('disabled'), "9 disabled true");
        assert.ok($('.button[data-content="val-8"]').hasClass('disabled'), "8 disabled true");
        assert.ok(!$('.button[data-content="val-7"]').hasClass('disabled'), "7 no disabled true");
        assert.ok(!$('.button[data-content="val-6"]').hasClass('disabled'), "6 no disabled true");
        assert.ok(!$('.button[data-content="val-5"]').hasClass('disabled'), "5 no disabled true");
        assert.ok(!$('.button[data-content="val-4"]').hasClass('disabled'), "4 no disabled true");
        assert.ok(!$('.button[data-content="val-3"]').hasClass('disabled'), "3 no disabled true");
        assert.ok(!$('.button[data-content="val-2"]').hasClass('disabled'), "2 no disabled true");
        assert.ok(!$('.button[data-content="val-1"]').hasClass('disabled'), "1 no disabled true");
        assert.ok(!$('.button[data-content="val-0"]').hasClass('disabled'), "0 no disabled true");
        done();
      });
    });
    QUnit.test("bin disabled test", function (assert) {
      let done = assert.async();
      init();
      $('.base.bin').trigger('click');
      setTimeout(function () {
        assert.ok($('.button[data-content="val-f"]').hasClass('disabled'), "f disabled true");
        assert.ok($('.button[data-content="val-e"]').hasClass('disabled'), "e disabled true");
        assert.ok($('.button[data-content="val-d"]').hasClass('disabled'), "d disabled true");
        assert.ok($('.button[data-content="val-c"]').hasClass('disabled'), "c disabled true");
        assert.ok($('.button[data-content="val-b"]').hasClass('disabled'), "b disabled true");
        assert.ok($('.button[data-content="val-a"]').hasClass('disabled'), "a disabled true");
        assert.ok($('.button[data-content="val-9"]').hasClass('disabled'), "9 disabled true");
        assert.ok($('.button[data-content="val-8"]').hasClass('disabled'), "8 disabled true");
        assert.ok($('.button[data-content="val-7"]').hasClass('disabled'), "7 disabled true");
        assert.ok($('.button[data-content="val-6"]').hasClass('disabled'), "6 disabled true");
        assert.ok($('.button[data-content="val-5"]').hasClass('disabled'), "5 disabled true");
        assert.ok($('.button[data-content="val-4"]').hasClass('disabled'), "4 disabled true");
        assert.ok($('.button[data-content="val-3"]').hasClass('disabled'), "3 disabled true");
        assert.ok($('.button[data-content="val-2"]').hasClass('disabled'), "2 disabled true");
        assert.ok(!$('.button[data-content="val-1"]').hasClass('disabled'), "1 no disabled true");
        assert.ok(!$('.button[data-content="val-0"]').hasClass('disabled'), "0 no disabled true");
        done();
      });
    });
    QUnit.module("monkey test");
    QUnit.test("keyboard dec monkey test", function (assert) {
      let done = assert.async();
      init();
      $('.button[data-content="val-3"]').trigger('click');
      $('.button[data-content="val-7"]').trigger('click');
      $('.button[data-content="val-8"]').trigger('click');
      setTimeout(function () {
        assert.equal($('.display .value').html(), '378', "number pass");
        $('.button[data-content="oper-div"]').trigger('click');
        setTimeout(function () {
          assert.equal($('.display .value').html(), '378', "div pass");
          $('.button[data-content="val-2"]').trigger('click');
          $('.button[data-content="val-1"]').trigger('click');
          setTimeout(function () {
            assert.equal($('.display .value').html(), '21', "number pass");
            $('.button[data-content="oper-sub"]').trigger('click');
            $('.button[data-content="oper-add"]').trigger('click');
            setTimeout(function () {
              assert.equal($('.display .value').html(), '21', "add, sub pass, change oper pass");
              $('.button[data-content="val-9"]').trigger('click');
              $('.button[data-content="val-4"]').trigger('click');
              setTimeout(function () {
                assert.equal($('.display .value').html(), '94', "number pass");
                $('.button[data-content="oper-mod"]').trigger('click');
                setTimeout(function () {
                  assert.equal($('.display .value').html(), '94', "mod");
                  $('.button[data-content="val-0"]').trigger('click');
                  $('.button[data-content="val-6"]').trigger('click');
                  $('.button[data-content="calc"]').trigger('click');
                  setTimeout(function () {
                    assert.equal($('.display .value').html(), '22', "enter pass");
                    Mousetrap.trigger('esc');
                    setTimeout(function () {
                      assert.equal($('.display .value').html(), '0', "clear pass");
                      $('.button[data-content="val-5"]').trigger('click');
                      $('.button[data-content="val-a"]').trigger('click');
                      $('.button[data-content="val-b"]').trigger('click');
                      $('.button[data-content="val-c"]').trigger('click');
                      $('.button[data-content="val-d"]').trigger('click');
                      $('.button[data-content="val-e"]').trigger('click');
                      $('.button[data-content="val-f"]').trigger('click');
                      setTimeout(function () {
                        assert.equal($('.display .value').html(), '5', "dec 10~15 disabled");
                        $('.button[data-content="oper-mul"]').trigger('click');
                        $('.button[data-content="val-4"]').trigger('click');
                        $('.button[data-content="val-1"]').trigger('click');
                        $('.button[data-content="bs"]').trigger('click');
                        setTimeout(function () {
                          assert.equal($('.display .value').html(), '4', "bs pass");
                          $('.button[data-content="val-2"]').trigger('click');
                          $('.button[data-content="neg"]').trigger('click');
                          setTimeout(function () {
                            assert.equal($('.display .value').html(), '-42', "neg pass");
                            $('.button[data-content="ce"]').trigger('click');
                            $('.button[data-content="val-9"]').trigger('click');
                            $('.button[data-content="calc"]').trigger('click');
                            setTimeout(function () {
                              assert.equal($('.display .value').html(), '45', "ce pass");
                              done();
                            });
                          });
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});
