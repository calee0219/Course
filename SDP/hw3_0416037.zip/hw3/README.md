# SPD hw3 unit test

## used
- QUnit
- JQuery

## require
- [x] Apply version control.
- [x] Output meaningful test title and test messages.
- [x] Group your test cases.
- [x] Simulate user control events using $el.trigger() function
- [x] Verify DOM output, and reset DOM states for each test group.
- [x] Try to implement at least one test case in command line.
- [x] Code coverage.
- [x] bug

## Details
0. Command line command: ```./node_modules/qunit/bin/cli.js -c calc.js -t tests_cmd.js```
1. Command line implement: isVal function
2. When testing coverage, you may need to used firefox. If you using chrome, it may have some http request problem(?)
3. Coverage: 98.5%
    * main.js 100%
    * calc.js 97.65%
    * I'm not sure how to test Array.prototype.
4. bug report:
    * in the spac, negative number must be two's complement, but it's one's complement
    * when type backspace after a operator, the result will be weird
    * press negative sign after operator will also get weird answer (I expect the neg sign is for the next number. Not copy another number from previous number)
    * press CE after an operation and get the equal value will have a weird answer