#include "p2.hpp"

namespace oop{

	Node* push(Node *top,int n){
	}
    Node* pop(Node *top){
	}
    void print(Node *top ){ 
     //Output specification: top->space->top->space->�K�K 
     //std::cout<<top<<" "; //show example

    } 
}
