#include<iostream>
#include<stack>
#include<string>
int main()
{
	std::string s;
	std::stack<char> p; 
	while(std::cin>>s)
	{
	     //fill you code  
		 
		 
		 //if the string is a palindrome 
		 std::cout<<"The string is not a Palindrome"<<std::endl;
		 
		 //if the string is not a palindrome
		 std::cout<<"The string is a Palindrome"<<std::endl;
		
	}
	
	
	return 0;
}
